<footer class="page-footer gradient-bg">
    <div class="footer-copyright">
        <div class="container">
            © 2018 Copyright SagarMaheshwary
        </div>
    </div>
</footer>